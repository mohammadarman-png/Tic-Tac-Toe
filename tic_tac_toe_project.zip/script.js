// script.js — Tic Tac Toe with animations, sound, and AI (minimax)
const cells = Array.from(document.querySelectorAll('.cell'));
const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
const resetBtn = document.getElementById('reset');
const modeSelect = document.getElementById('mode');
const clickSound = document.getElementById('click-sound');
const winSound = document.getElementById('win-sound');

let board = Array(9).fill('');
let currentPlayer = 'X';
let running = true;
let scores = { X:0, O:0, D:0 };

const winPatterns = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6]
];

// utilities
function playSound(el){
  try{ el.currentTime = 0; el.play(); }catch(e){}
}

function updateStatus(txt){ statusEl.textContent = txt; }

function resetBoardUI(){
  cells.forEach(c => {
    c.textContent = '';
    c.className = 'cell';
    c.classList.remove('win');
    c.removeAttribute('aria-disabled');
  });
}

// main actions
function startNewGame(){
  board.fill('');
  currentPlayer = 'X';
  running = true;
  resetBoardUI();
  updateStatus("Player X's Turn");
}

function handleCellClick(e){
  const idx = Number(e.target.dataset.index);
  if (!running || board[idx]) return;
  makeMove(idx, currentPlayer);
  playSound(clickSound);
  if (checkGameOver()) return;
  if (modeSelect.value === '1p'){
    // computer move (short delay for UX)
    running = false;
    updateStatus('Computer is thinking...');
    setTimeout(() => {
      const compIdx = bestMove(board, 'O');
      makeMove(compIdx, 'O');
      playSound(clickSound);
      checkGameOver();
      running = true;
    }, 380);
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateStatus(`Player ${currentPlayer}'s Turn`);
  }
}

function makeMove(idx, player){
  board[idx] = player;
  const el = cells[idx];
  el.textContent = player;
  el.classList.add(player === 'X' ? 'x' : 'o');
  el.setAttribute('aria-disabled', 'true');
  // small pop animation
  el.animate([{ transform: 'scale(0.85)' }, { transform: 'scale(1.02)' }, { transform: 'scale(1)' }], { duration: 220, easing: 'cubic-bezier(.25,.9,.35,1)' });
}

function checkGameOver(){
  // win?
  for (const pattern of winPatterns){
    const [a,b,c] = pattern;
    if (board[a] && board[a] === board[b] && board[b] === board[c]){
      // highlight
      [a,b,c].forEach(i => cells[i].classList.add('win'));
      running = false;
      updateStatus(`Player ${board[a]} Wins!`);
      playSound(winSound);
      scores[board[a]]++;
      updateScores();
      return true;
    }
  }
  // draw?
  if (!board.includes('')){
    running = false;
    updateStatus("It's a Draw");
    scores.D++;
    updateScores();
    return true;
  }
  return false;
}

function updateScores(){
  document.getElementById('scoreX').textContent = scores.X;
  document.getElementById('scoreO').textContent = scores.O;
  document.getElementById('scoreD').textContent = scores.D;
}

/* ========== Simple Minimax (perfect play) for small board ========== */
function bestMove(bd, player){
  // if board empty and computer is 'O', choose center for speed/UX
  if (bd.every(v => v === '')) return 4;

  const opponent = player === 'O' ? 'X' : 'O';

  function evaluate(boardState){
    for (const p of ['X','O']){
      for (const pat of winPatterns){
        if (pat.every(i => boardState[i] === p)) return p === player ? 10 : -10;
      }
    }
    if (!boardState.includes('')) return 0;
    return null; // not terminal
  }

  function minimax(boardState, depth, isMax){
    const score = evaluate(boardState);
    if (score !== null) return score;
    if (isMax){
      let best = -Infinity;
      for (let i=0;i<9;i++){
        if (!boardState[i]){
          boardState[i] = player;
          const val = minimax(boardState, depth+1, false);
          boardState[i] = '';
          best = Math.max(best, val);
        }
      }
      return best - depth*0.01; // prefer faster wins
    } else {
      let best = Infinity;
      for (let i=0;i<9;i++){
        if (!boardState[i]){
          boardState[i] = opponent;
          const val = minimax(boardState, depth+1, true);
          boardState[i] = '';
          best = Math.min(best, val);
        }
      }
      return best + depth*0.01;
    }
  }

  let bestVal = -Infinity;
  let move = -1;
  for (let i=0;i<9;i++){
    if (!bd[i]){
      bd[i] = player;
      const val = minimax(bd, 0, false);
      bd[i] = '';
      if (val > bestVal){
        bestVal = val; move = i;
      }
    }
  }
  // fallback: random available
  if (move === -1){
    const avail = bd.map((v,i)=> v?null:i).filter(x=>x!==null);
    move = avail[Math.floor(Math.random()*avail.length)];
  }
  return move;
}

/* ========== Init & events ========== */
cells.forEach(c => c.addEventListener('click', handleCellClick));
cells.forEach(c => c.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); c.click(); }
}));

resetBtn.addEventListener('click', () => {
  startNewGame();
});

modeSelect.addEventListener('change', () => {
  startNewGame();
});

// start
startNewGame();
